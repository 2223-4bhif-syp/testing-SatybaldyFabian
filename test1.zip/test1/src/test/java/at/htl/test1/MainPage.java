package at.htl.test1;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebDriver;

import static com.codeborne.selenide.Selenide.*;

public class MainPage {
    public SelenideElement pageHeader = $x("//input[placeholder() = 'Suchen auf Amazon.de' ]");
}
