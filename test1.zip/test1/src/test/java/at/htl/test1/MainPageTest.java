package at.htl.test1;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.logevents.SelenideLogger;
import io.qameta.allure.selenide.AllureSelenide;
import org.junit.jupiter.api.*;
import org.openqa.selenium.WebElement;

import static org.junit.jupiter.api.Assertions.*;

import static com.codeborne.selenide.Condition.attribute;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class MainPageTest {
    MainPage mainPage = new MainPage();


    @BeforeAll
    public static void setUpAll() {
        Configuration.browserSize = "1280x800";
        SelenideLogger.addListener("allure", new AllureSelenide());
    }

    @BeforeEach
    public void setUp() {
        open("https://www.amazon.de/");
    }


    @Test
    public void firstTestCase() {
        try {
            System.out.println("Logging into Lambda Test Sign Up Page");
            mainPage.pageHeader.click();
            $x("//input[placeholder() = 'Suchen auf Amazon.de' ]").sendKeys("Smart Phone");
            $x("//input[placeholder() = 'Suchen auf Amazon.de' ]").shouldHave(attribute("value", "Smart Phone"));
            System.out.println("Clicked on the Sign In Button.");
        } catch (Exception e) {
        }
    }

}
